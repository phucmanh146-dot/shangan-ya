// api/ask-ai.js —— 真·AI 接口。网页把问题 POST 过来，这份代码代着密钥去问大模型再把回答传回去。
//
// mode 决定用哪套人设和输出格式：
//   stuck      卡壳了，给具体的下一步（默认）
//   steps      把一段教程/文章/视频章节拆成一关一关，返回 JSON 数组
//   checkpoint 5分钟/过半检查点：根据已完成的关数说人话地汇报成果
//   coach      督促：直接、不留情面，但不羞辱人，只对事
//   plan       给今天这批任务的排程建议
const { handler, needKey, chat, looseJson } = require('./_lib');

const SYSTEM = {
  stuck:
    '你是学习/任务规划教练。学生卡住了，你要先判断卡的是哪一类：概念没懂 / 报错解决不了 / 不知道从哪下手 / 单纯在分心。' +
    '然后只给一个能在 10 分钟内做完的、具体到动作的下一步，不要给一长串方案，不要说"你可以试试"这种废话。' +
    '中文回答，180 字以内。如果给了参考资料，引用里面的事实，并在句末标出来自第几条。',
  steps:
    '你要把一段教程内容拆成"一关一关"的小步骤，给一个迟迟不敢开始的人用。规则：' +
    '每关是一个具体动作，不是一个话题；每关一句话，20 字以内；从最容易的开始，第一关必须 5 分钟内能做完；' +
    '总共 4-10 关。只输出一个 JSON 数组，形如 ["第一关的动作","第二关的动作"]，不要输出任何别的字。',
  checkpoint:
    '你在番茄钟中途做一次检查。根据给的进度，用一到两句话说清楚"到现在为止已经做成了什么"，' +
    '要具体、可核对，不要鼓励性的空话，不要感叹号。最后加一句"准吗？"。中文，60 字以内。',
  coach:
    '你是一个严格的监督者。学生说好要做的事没在做。用直接、不绕弯的话把事实摆出来：他答应了什么、现在实际在干什么、' +
    '继续这样会有什么具体后果。对事不对人——不许人身攻击、不许侮辱、不许拿伤害自己或家人的话吓唬人。' +
    '最后给一个此刻就能做的动作。中文，80 字以内。',
  plan:
    '你是日程规划助手。给出简短的排程建议：哪件先做、为什么、哪件今天可以不做。中文，150 字以内，不要列长表格。'
};

module.exports = handler(['POST'], async function(req, res, body){
  const apiKey = needKey(res, 'SILICONFLOW_API_KEY');
  if(!apiKey) return;

  const mode = (body.mode || 'stuck').toString();
  if(!SYSTEM[mode]){ res.status(400).json({ error: '不认识的 mode：' + mode, modes: Object.keys(SYSTEM) }); return; }

  const question = (body.question || body.text || '').toString().trim();
  if(!question){ res.status(400).json({ error: '问题内容不能为空' }); return; }

  const model = body.model || process.env.TEXT_MODEL || 'deepseek-ai/DeepSeek-V3';

  // 可选的参考资料：搜索结果或者抓下来的网页正文，拼在用户消息前面
  let user = question;
  if(body.context){
    const ctx = String(body.context).slice(0, 12000);
    user = '【参考资料】\n' + ctx + '\n\n【我的问题】\n' + question;
  }

  const messages = [
    { role: 'system', content: SYSTEM[mode] },
    { role: 'user', content: user }
  ];

  let out;
  try {
    out = await chat(apiKey, model, messages, {
      temperature: mode === 'steps' ? 0.3 : 0.7,
      max_tokens: mode === 'steps' ? 900 : 600
    });
  } catch(e){
    res.status(e.status || 502).json({ error: '调用模型失败', detail: e.detail || String(e.message || e) });
    return;
  }

  if(mode === 'steps'){
    const arr = looseJson(out.text);
    const steps = Array.isArray(arr)
      ? arr.map(function(x){ return typeof x === 'string' ? x : (x && (x.text || x.title || x.step) || ''); })
           .map(function(s){ return String(s).trim(); })
           .filter(Boolean)
           .slice(0, 12)
      : [];
    if(!steps.length){
      // 拆不出来就如实说，不要编几关假的糊弄过去
      res.status(200).json({ steps: [], reply: out.text, warn: '模型这次没给出能用的关卡列表，原文放在 reply 里了' });
      return;
    }
    res.status(200).json({ steps: steps, model: model });
    return;
  }

  res.status(200).json({ reply: out.text, model: model, mode: mode });
});
