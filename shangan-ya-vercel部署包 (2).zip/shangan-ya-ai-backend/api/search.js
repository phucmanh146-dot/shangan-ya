// api/search.js —— 全网搜索。
//
// 真·搜索需要一家搜索服务的 key。配了哪家就用哪家，一个都没配就退到一个不需要 key 的
// 兜底抓取（DuckDuckGo 轻量版）。兜底能用，但结果少、随时可能被对方挡掉——这种时候
// 返回 degraded:true，网页要如实告诉用户"现在是兜底模式"，不许假装是完整搜索。
//
// 想开真·搜索：在 Vercel 环境变量里加任意一条（推荐博查，中文结果好）：
//   BOCHA_API_KEY   https://open.bochaai.com
//   TAVILY_API_KEY  https://tavily.com
//   SERPER_API_KEY  https://serper.dev
//   BRAVE_API_KEY   https://brave.com/search/api
const { handler, fetchTimeout } = require('./_lib');

function clean(s){
  return String(s || '').replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

async function viaBocha(key, q, n){
  const r = await fetchTimeout('https://api.bochaai.com/v1/web-search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ query: q, count: n, summary: true })
  }, 20000);
  const d = await r.json();
  if(!r.ok) throw new Error('博查返回 ' + r.status);
  const pages = (d && d.data && d.data.webPages && d.data.webPages.value) || [];
  return pages.map(function(p){ return { title: p.name, url: p.url, snippet: clean(p.summary || p.snippet) }; });
}
async function viaTavily(key, q, n){
  const r = await fetchTimeout('https://api.tavily.com/search', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ api_key: key, query: q, max_results: n })
  }, 20000);
  const d = await r.json();
  if(!r.ok) throw new Error('Tavily 返回 ' + r.status);
  return (d.results || []).map(function(p){ return { title: p.title, url: p.url, snippet: clean(p.content) }; });
}
async function viaSerper(key, q, n){
  const r = await fetchTimeout('https://google.serper.dev/search', {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-KEY': key },
    body: JSON.stringify({ q: q, num: n, hl: 'zh-cn' })
  }, 20000);
  const d = await r.json();
  if(!r.ok) throw new Error('Serper 返回 ' + r.status);
  return (d.organic || []).map(function(p){ return { title: p.title, url: p.link, snippet: clean(p.snippet) }; });
}
async function viaBrave(key, q, n){
  const r = await fetchTimeout('https://api.search.brave.com/res/v1/web/search?q=' + encodeURIComponent(q) + '&count=' + n, {
    headers: { 'Accept': 'application/json', 'X-Subscription-Token': key }
  }, 20000);
  const d = await r.json();
  if(!r.ok) throw new Error('Brave 返回 ' + r.status);
  return ((d.web && d.web.results) || []).map(function(p){ return { title: p.title, url: p.url, snippet: clean(p.description) }; });
}
// 不需要 key 的兜底：DuckDuckGo 轻量版的 HTML
async function viaFallback(q, n){
  const r = await fetchTimeout('https://lite.duckduckgo.com/lite/?q=' + encodeURIComponent(q), {
    method: 'GET',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
      'Accept-Language': 'zh-CN,zh;q=0.9'
    }
  }, 15000);
  if(!r.ok) throw new Error('兜底搜索返回 ' + r.status);
  const html = await r.text();
  const out = [];
  const linkRe = /<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  const snipRe = /<td[^>]*class="result-snippet"[^>]*>([\s\S]*?)<\/td>/gi;
  const snips = [];
  let ms;
  while((ms = snipRe.exec(html)) !== null) snips.push(clean(ms[1]));
  let m, i = 0;
  while((m = linkRe.exec(html)) !== null && out.length < n){
    let url = m[1];
    const uddg = url.match(/[?&]uddg=([^&]+)/);
    if(uddg) url = decodeURIComponent(uddg[1]);
    out.push({ title: clean(m[2]), url: url, snippet: snips[i] || '' });
    i++;
  }
  return out;
}

module.exports = handler(['GET', 'POST'], async function(req, res, body){
  const q = ((req.method === 'GET' ? (req.query && req.query.q) : body.q || body.query) || '').toString().trim();
  if(!q){ res.status(400).json({ error: '搜索词不能为空' }); return; }
  const n = Math.min(10, Math.max(1, parseInt(body.n || (req.query && req.query.n), 10) || 6));

  const chain = [
    ['BOCHA_API_KEY',  '博查',   viaBocha],
    ['TAVILY_API_KEY', 'Tavily', viaTavily],
    ['SERPER_API_KEY', 'Serper', viaSerper],
    ['BRAVE_API_KEY',  'Brave',  viaBrave]
  ];
  const tried = [];
  for(const [env, name, fn] of chain){
    const key = process.env[env];
    if(!key) continue;
    try {
      const results = await fn(key, q, n);
      if(results.length){ res.status(200).json({ query: q, provider: name, degraded: false, results: results }); return; }
      tried.push(name + '(没结果)');
    } catch(e){ tried.push(name + '(' + String(e.message || e) + ')'); }
  }

  try {
    const results = await viaFallback(q, n);
    res.status(200).json({
      query: q, provider: '兜底抓取', degraded: true, results: results, tried: tried,
      note: '现在没有配任何搜索服务的 key，这是不需要 key 的兜底抓取——结果比正经搜索少，也可能随时被对方挡掉。想要完整搜索，去 Vercel 环境变量加一条 BOCHA_API_KEY（中文结果最好）。'
    });
  } catch(e){
    res.status(503).json({
      error: '搜索这条路现在走不通', tried: tried.concat(['兜底(' + String(e.message || e) + ')']),
      how: '去 Vercel 项目 → Settings → Environment Variables 加一条 BOCHA_API_KEY / TAVILY_API_KEY / SERPER_API_KEY / BRAVE_API_KEY，加完 Redeploy 一次。'
    });
  }
});
