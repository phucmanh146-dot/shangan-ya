// api/models.js —— 把 SiliconFlow 账号下可用的模型列出来，方便在"我的"页里换模型。
const { handler, needKey, fetchTimeout } = require('./_lib');

module.exports = handler(['GET', 'POST'], async function(req, res){
  const apiKey = needKey(res, 'SILICONFLOW_API_KEY');
  if(!apiKey) return;
  const r = await fetchTimeout('https://api.siliconflow.cn/v1/models?sub_type=chat', {
    headers: { 'Authorization': 'Bearer ' + apiKey }
  }, 20000);
  const data = await r.json().catch(function(){ return null; });
  if(!r.ok){ res.status(r.status).json({ error: 'SiliconFlow 返回错误', detail: data }); return; }
  const ids = (data && data.data || []).map(function(m){ return m.id; }).filter(Boolean);
  res.status(200).json({ count: ids.length, models: ids });
});
