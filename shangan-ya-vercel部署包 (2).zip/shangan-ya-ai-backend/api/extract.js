// api/extract.js —— 把一个链接变成能读的正文。不需要任何 key。
//
// B站走官方公开接口，拿得到标题、简介和分P/章节——这正好就是"拆成一关一关"要的东西。
// 其它网站走通用抓取：下载 HTML，去掉脚本样式导航，留正文。
//
// 说实话的地方：小红书、抖音这类站点对服务器抓取封得很死，多半只会返回一个空壳。
// 遇到这种情况返回 thin:true，网页要直接告诉用户"这个平台抓不到，请把正文复制过来"，
// 不许拿一个空结果假装成功。
const { handler, fetchTimeout } = require('./_lib');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

function stripHtml(html){
  return String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<(nav|header|footer|aside|form|svg)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<\/(p|div|li|h[1-6]|br|tr)>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t ]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .split('\n').map(function(l){ return l.trim(); }).filter(Boolean).join('\n')
    .trim();
}
function metaOf(html, name){
  const re = new RegExp('<meta[^>]+(?:property|name)=["\']' + name + '["\'][^>]+content=["\']([^"\']*)["\']', 'i');
  const m = html.match(re);
  if(m) return m[1];
  const re2 = new RegExp('<meta[^>]+content=["\']([^"\']*)["\'][^>]+(?:property|name)=["\']' + name + '["\']', 'i');
  const m2 = html.match(re2);
  return m2 ? m2[1] : '';
}

async function bilibili(url){
  const bv = (url.match(/(BV[0-9A-Za-z]{10})/) || [])[1];
  const av = (url.match(/\/av(\d+)/) || [])[1];
  if(!bv && !av) return null;
  const api = 'https://api.bilibili.com/x/web-interface/view?' + (bv ? ('bvid=' + bv) : ('aid=' + av));
  const r = await fetchTimeout(api, {
    headers: { 'User-Agent': UA, 'Referer': 'https://www.bilibili.com/', 'Accept': 'application/json' }
  }, 15000);
  const d = await r.json().catch(function(){ return null; });
  if(!d || d.code !== 0 || !d.data) return null;
  const v = d.data;
  const parts = (v.pages || []).map(function(p, i){ return (i + 1) + '. ' + p.part; });
  const text = [
    '标题：' + (v.title || ''),
    v.desc ? ('\n简介：\n' + v.desc) : '',
    parts.length > 1 ? ('\n分P/章节：\n' + parts.join('\n')) : ''
  ].filter(Boolean).join('\n');
  return { title: v.title || '', text: text, source: 'bilibili官方接口', chapters: parts, cover: v.pic || '' };
}

module.exports = handler(['POST'], async function(req, res, body){
  const url = (body.url || '').toString().trim();
  if(!/^https?:\/\//i.test(url)){ res.status(400).json({ error: '需要一个以 http(s):// 开头的链接' }); return; }

  // B站特判：官方接口比抓网页靠谱得多
  if(/bilibili\.com|b23\.tv/i.test(url)){
    try {
      const bi = await bilibili(url);
      if(bi && bi.text){ res.status(200).json(Object.assign({ url: url, chars: bi.text.length, thin: false }, bi)); return; }
    } catch(e){ /* 掉下去走通用抓取 */ }
  }

  let r;
  try {
    r = await fetchTimeout(url, {
      headers: { 'User-Agent': UA, 'Accept-Language': 'zh-CN,zh;q=0.9', 'Accept': 'text/html,application/xhtml+xml' },
      redirect: 'follow'
    }, 20000);
  } catch(e){
    res.status(502).json({ error: '打不开这个链接', detail: String(e.message || e) });
    return;
  }
  if(!r.ok){
    res.status(200).json({
      url: url, title: '', text: '', chars: 0, thin: true, status: r.status,
      note: '对方服务器回了 ' + r.status + '，多半是挡住了服务器抓取。把正文复制粘贴过来，一样能拆。'
    });
    return;
  }
  const html = await r.text();
  const title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || metaOf(html, 'og:title') || '';
  let text = stripHtml(html);
  if(text.length > 20000) text = text.slice(0, 20000);
  const desc = metaOf(html, 'og:description') || metaOf(html, 'description');
  // 正文太短＝多半是个需要 JS 才能渲染的空壳（小红书/抖音常见）
  const thin = text.length < 200;
  if(thin && desc) text = desc;

  res.status(200).json({
    url: url,
    title: String(title).trim(),
    text: text,
    chars: text.length,
    thin: thin,
    source: '通用网页抓取',
    note: thin
      ? '这个页面靠 JS 才能渲染出内容（小红书、抖音这类基本都是），服务器抓下来只有一个空壳。把正文或者视频文案复制粘贴过来，照样能拆成关卡。'
      : ''
  });
});
