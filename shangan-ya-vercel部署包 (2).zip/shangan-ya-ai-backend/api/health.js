// api/health.js —— 自检：告诉网页"这台后端现在能干什么"。
// 只回 true/false，绝不回密钥本身。网页拿这个结果决定哪些按钮能点、哪些要如实说"还没开通"。
const { handler } = require('./_lib');

const SEARCH_PROVIDERS = [
  ['BOCHA_API_KEY',  '博查'],
  ['TAVILY_API_KEY', 'Tavily'],
  ['SERPER_API_KEY', 'Serper'],
  ['BRAVE_API_KEY',  'Brave']
];

module.exports = handler(['GET', 'POST'], async function(req, res){
  const hasAI = !!process.env.SILICONFLOW_API_KEY;
  let searchProvider = null;
  for(const [env, name] of SEARCH_PROVIDERS){
    if(process.env[env]){ searchProvider = name; break; }
  }
  res.status(200).json({
    ok: true,
    service: '上岸鸭后端',
    version: 'v1',
    time: new Date().toISOString(),
    capabilities: {
      ai: hasAI,                       // 卡壳给思路 / 拆关卡 / 检查点
      vision: hasAI,                   // 看画面判断专注（跟 AI 同一把钥匙）
      search: !!searchProvider,        // 真·搜索（配了搜索服务的 key）
      searchProvider: searchProvider,  // 配的是哪家；没配就是 null
      searchFallback: true,            // 没配 key 时的兜底抓取（能用，但结果少、可能被挡）
      extract: true,                   // 网页/B站正文抽取——不需要任何 key
      calendar: 'client-ics'           // 日历是网页本地生成 .ics，数据不经过服务器
    },
    // 这台后端要不要口令。false = 谁知道地址谁就能用它烧你的模型额度。
    tokenRequired: !!process.env.APP_TOKEN,
    models: {
      text: process.env.TEXT_MODEL || 'deepseek-ai/DeepSeek-V3',
      vision: process.env.VISION_MODEL || 'Qwen/Qwen2.5-VL-7B-Instruct'
    },
    hint: hasAI ? '密钥已就位' : '还差 SILICONFLOW_API_KEY：Vercel 项目 → Settings → Environment Variables 加上，然后 Redeploy',
    warn: process.env.APP_TOKEN ? null
      : '这台后端现在没设口令：谁知道这个地址，谁就能拿它去烧你的模型额度。加一条环境变量 APP_TOKEN（自己编一串长点的字）就能关上。'
  });
}, { open: true });
// health 故意不要口令——App 要靠它判断"后端在不在、要不要口令"，它一个字的秘密都不返回。
module.exports.__open = true;
