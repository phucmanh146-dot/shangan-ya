// api/_lib.js —— 所有接口共用的基础件。文件名以 _ 开头，Vercel 不会把它当成一个可访问的接口。
//
// 密钥只活在 Vercel 后台的环境变量里。它不写在代码里，不进 git，不出现在浏览器能看到的任何地方——
// 这就是"必须有个后端"的全部理由：密钥要是直接写在网页 JS 里，谁按下 F12 都能拿走。

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-app-token',
  'Access-Control-Max-Age': '86400'
};

function applyCors(res){
  Object.keys(CORS).forEach(function(k){ res.setHeader(k, CORS[k]); });
}

// 统一的入口包装：处理 CORS 预检、口令校验、方法校验、JSON 解析、未捕获异常。
//
// 口令（APP_TOKEN）：这台后端一旦对公网开放，任何知道地址的人都能拿它去烧你的模型额度。
// 所以在 Vercel 环境变量里加一条 APP_TOKEN（自己随便编一串长一点的字），加了之后除了
// /api/health 之外的接口都必须带对 x-app-token 才给用。App 的"我的"页里填同一串。
// 不加也能跑，但 /api/health 会明说这台后端是敞着的。
function checkToken(req, res, opts){
  const want = process.env.APP_TOKEN;
  if(!want || (opts && opts.open)) return true;
  const got = req.headers['x-app-token'] ||
    (req.query && req.query.token) ||
    (typeof req.body === 'object' && req.body && req.body.token) || '';
  if(String(got) === String(want)) return true;
  res.status(401).json({
    error: '口令不对',
    how: '这台后端设了 APP_TOKEN。去 App 的「我的」→「后端设置」里，把同一串口令填进去。'
  });
  return false;
}

function handler(methods, fn, opts){
  return async function(req, res){
    applyCors(res);
    if(req.method === 'OPTIONS'){ res.status(204).end(); return; }
    if(!checkToken(req, res, opts)) return;
    if(methods.indexOf(req.method) === -1){
      res.status(405).json({ error: '这个接口只接受 ' + methods.join('/') + ' 请求' });
      return;
    }
    let body = {};
    if(req.method === 'POST'){
      try {
        body = typeof req.body === 'string' ? (req.body ? JSON.parse(req.body) : {}) : (req.body || {});
      } catch(e){
        res.status(400).json({ error: '请求内容不是合法的 JSON' });
        return;
      }
    }
    try {
      await fn(req, res, body);
    } catch(e){
      res.status(500).json({ error: '服务器出错了', detail: String(e && e.message || e) });
    }
  };
}

function needKey(res, name){
  const v = process.env[name];
  if(!v){
    res.status(503).json({
      error: '服务器还没配置 ' + name,
      how: '去 Vercel 项目 → Settings → Environment Variables 加上这一条，加完必须 Redeploy 一次才生效。密钥只填在那个页面上，别发到任何聊天里。',
      missing: name
    });
    return null;
  }
  return v;
}

// 带超时的 fetch —— Vercel 的函数有执行时限，卡死的上游要能自己断掉
async function fetchTimeout(url, opts, ms){
  const ctrl = new AbortController();
  const timer = setTimeout(function(){ ctrl.abort(); }, ms || 20000);
  try {
    return await fetch(url, Object.assign({}, opts, { signal: ctrl.signal }));
  } finally {
    clearTimeout(timer);
  }
}

// 调 SiliconFlow 的对话接口。messages 直接透传，方便文字模型和视觉模型共用。
async function chat(apiKey, model, messages, opts){
  opts = opts || {};
  const r = await fetchTimeout('https://api.siliconflow.cn/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
    body: JSON.stringify({
      model: model,
      messages: messages,
      temperature: typeof opts.temperature === 'number' ? opts.temperature : 0.6,
      max_tokens: opts.max_tokens || 700,
      stream: false
    })
  }, opts.timeout || 45000);
  const data = await r.json().catch(function(){ return null; });
  if(!r.ok){
    const e = new Error('上游模型返回 ' + r.status);
    e.status = r.status; e.detail = data;
    throw e;
  }
  const text = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  return { text: text || '', raw: data };
}

// 模型有时会把 JSON 包在```里、或者前后带一句废话。尽量把里面的 JSON 捞出来。
function looseJson(text){
  if(!text) return null;
  let s = String(text).trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if(fence) s = fence[1].trim();
  try { return JSON.parse(s); } catch(e){}
  const a = s.indexOf('['), b = s.lastIndexOf(']');
  if(a >= 0 && b > a){ try { return JSON.parse(s.slice(a, b + 1)); } catch(e){} }
  const c = s.indexOf('{'), d = s.lastIndexOf('}');
  if(c >= 0 && d > c){ try { return JSON.parse(s.slice(c, d + 1)); } catch(e){} }
  return null;
}

module.exports = { handler, needKey, fetchTimeout, chat, looseJson, applyCors };
