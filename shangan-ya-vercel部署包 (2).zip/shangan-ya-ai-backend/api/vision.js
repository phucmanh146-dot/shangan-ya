// api/vision.js —— 让视觉模型看一眼摄像头画面，判断"这会儿是真在做，还是在看手机/离开了"。
//
// 隐私上这是整套里唯一会把画面传出设备的功能：默认关闭，网页那边必须用户自己打开才会调用。
// 服务器只转发、不存档——画面不落任何盘、不写任何日志。
const { handler, needKey, chat, looseJson } = require('./_lib');

const PROMPT =
  '这是一个学生学习时的摄像头画面。只判断这一件事：他此刻在专心做事，还是在走神。\n' +
  '严格按这个 JSON 回答，不要输出任何别的字：\n' +
  '{"state":"focused|phone|away|slouch|unsure","confidence":0到1的小数,"note":"12字以内的中文说明"}\n' +
  'state 含义：focused=人在、面朝屏幕或纸面在做事；phone=在看手机；away=画面里没人；' +
  'slouch=人在但明显趴着/靠着/在发呆；unsure=看不清就老实用这个，不要猜。';

module.exports = handler(['POST'], async function(req, res, body){
  const apiKey = needKey(res, 'SILICONFLOW_API_KEY');
  if(!apiKey) return;

  let image = (body.image || '').toString();
  if(!image){ res.status(400).json({ error: '需要一张画面（base64 的 data URL）' }); return; }
  if(!/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(image)){
    res.status(400).json({ error: '画面格式不对，需要 data:image/jpeg;base64,... 这种' });
    return;
  }
  // 4MB 的上限，防止有人往这儿塞一张巨图把函数打爆
  if(image.length > 4 * 1024 * 1024){ res.status(413).json({ error: '画面太大了，前端请先压到 640px 宽再传' }); return; }

  const model = body.model || process.env.VISION_MODEL || 'Qwen/Qwen2.5-VL-7B-Instruct';
  let out;
  try {
    out = await chat(apiKey, model, [{
      role: 'user',
      content: [
        { type: 'image_url', image_url: { url: image } },
        { type: 'text', text: PROMPT }
      ]
    }], { temperature: 0.1, max_tokens: 120, timeout: 40000 });
  } catch(e){
    res.status(e.status || 502).json({
      error: '视觉模型调用失败', model: model, detail: e.detail || String(e.message || e),
      how: '如果是"模型不存在"，去 Vercel 环境变量加一条 VISION_MODEL，填一个你 SiliconFlow 账号里有的视觉模型 id。'
    });
    return;
  }

  const j = looseJson(out.text) || {};
  const state = ['focused', 'phone', 'away', 'slouch', 'unsure'].indexOf(j.state) >= 0 ? j.state : 'unsure';
  res.status(200).json({
    state: state,
    confidence: typeof j.confidence === 'number' ? Math.max(0, Math.min(1, j.confidence)) : null,
    note: (j.note || '').toString().slice(0, 30),
    model: model,
    rawText: state === 'unsure' ? out.text.slice(0, 200) : undefined
  });
});
